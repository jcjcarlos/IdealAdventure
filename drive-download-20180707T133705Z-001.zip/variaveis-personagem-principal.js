/*
 Aqui foram definidas as variáveis do personagem principal. Não precisa mexer aqui. :)
*/
let tipo_personagem1_1 = $('#tipo_personagem1-1');
let tipo_personagem1_2 = $('#tipo_personagem1-2');
let tipo_personagem1_3 = $('#tipo_personagem1-3');
let tipo_personagem1_4 = $('#tipo_personagem1-4');

let forca_personagem_1 = $('#forca_personagem_1');
let carisma_personagem_1 = $('#carisma_personagem_1');
let sabedoria_personagem_1 = $('#sabedoria_personagem_1');
let velocidade_personagem_1 = $('#velocidade_personagem_1');
let regeneracao_personagem_1 = $('#regeneracao_personagem_1');
let magica_personagem_1 = $('#magica_personagem_1');

/*
 Aqui foram definidos os valores iniciais para os atributos do seu personagem.
 Altere os dados do pesonagem modificando os valores das variáveis abaixo!
*/
forca_personagem_1.css('width', '10%');
carisma_personagem_1.css('width', '20%');
sabedoria_personagem_1.css('width', '30%');
velocidade_personagem_1.css('width', '40%');
regeneracao_personagem_1.css('width', '50%');
magica_personagem_1.css('width', '90%');

tipo_personagem1_1.html('Elfo');
tipo_personagem1_2.html('Venenoso');
tipo_personagem1_3.html('Fantasma');
tipo_personagem1_4.html('Sombrio');
